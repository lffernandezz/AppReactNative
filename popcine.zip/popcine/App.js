import React from 'react';
import { SafeAreaView, ScrollView, Text, View, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  // Dados de exemplo para filmes e séries
  const movies = [
    {
      id: 1,
      title: 'Avatar: O Caminho da Água',
      description: 'A sequência de Avatar, onde Jake Sully e Neytiri enfrentam novos desafios em Pandora.',
      image: 'https://image.tmdb.org/t/p/w500/2fr0K9N4uTu9shFjjO9gu8pN58v.jpg',
    },
    {
      id: 2,
      title: 'Stranger Things',
      description: 'Uma série de mistério e ficção científica que acontece nos anos 80, cheia de aventuras.',
      image: 'https://image.tmdb.org/t/p/w500/7zgxfWbu9ZjtQkRYrgZj0y8pwxm.jpg',
    },
    {
      id: 3,
      title: 'The Witcher',
      description: 'Um caçador de monstros, Geralt de Rívia, enfrenta dilemas enquanto luta contra criaturas sobrenaturais.',
      image: 'https://image.tmdb.org/t/p/w500/o6OpA1z3qsHOBLTA1eq4oz8JMLX.jpg',
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Popcine - Filmes e Séries</Text>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.movieList}>
          {movies.map((movie) => (
            <TouchableOpacity key={movie.id} style={styles.movieCard}>
              <Image source={{ uri: movie.image }} style={styles.movieImage} />
              <View style={styles.movieInfo}>
                <Text style={styles.movieTitle}>{movie.title}</Text>
                <Text style={styles.movieDescription}>{movie.description}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// Estilos inspirados no design da Netflix
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#141414',
    paddingTop: 50,
    paddingHorizontal: 20,
  },
  header: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 20,
    textAlign: 'center',
  },
  scrollContainer: {
    paddingBottom: 20,
  },
  movieList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  movieCard: {
    width: '48%',
    marginBottom: 20,
    borderRadius: 10,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 10,
  },
  movieImage: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    resizeMode: 'cover',
  },
  movieInfo: {
    backgroundColor: '#141414',
    padding: 10,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    borderRadius: 10,
  },
  movieTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  movieDescription: {
    fontSize: 12,
    color: '#b3b3b3',
  },
});

