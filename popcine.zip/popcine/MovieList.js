import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { styles } from './styles';

const movies = [
  {
    id: 1,
    title: 'Avatar: O Caminho da Água',
    description: 'A sequência de Avatar, onde Jake Sully e Neytiri enfrentam novos desafios em Pandora.',
    image: 'https://image.tmdb.org/t/p/w500/2fr0K9N4uTu9shFjjO9gu8pN58v.jpg',
  },
  {
    id: 2,
    title: 'Stranger Things',
    description: 'Uma série de mistério e ficção científica que acontece nos anos 80, cheia de aventuras.',
    image: 'https://image.tmdb.org/t/p/w500/7zgxfWbu9ZjtQkRYrgZj0y8pwxm.jpg',
  },
  {
    id: 3,
    title: 'The Witcher',
    description: 'Um caçador de monstros, Geralt de Rívia, enfrenta dilemas enquanto luta contra criaturas sobrenaturais.',
    image: 'https://image.tmdb.org/t/p/w500/o6OpA1z3qsHOBLTA1eq4oz8JMLX.jpg',
  },
];

const MovieList = () => {
  return (
    <View>
      {movies.map((movie) => (
        <TouchableOpacity key={movie.id} style={styles.movieCard}>
          <Image source={{ uri: movie.image }} style={styles.movieImage} />
          <View style={styles.movieInfo}>
            <Text style={styles.movieTitle}>{movie.title}</Text>
            <Text style={styles.movieDescription}>{movie.description}</Text>
          </View>
        </TouchableOpacity>
      ))}
    </View>
  );
};

export default MovieList;
